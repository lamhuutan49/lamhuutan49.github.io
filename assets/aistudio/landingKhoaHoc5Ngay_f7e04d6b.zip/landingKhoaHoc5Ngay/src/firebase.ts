import {initializeApp} from 'firebase/app';
import {getAuth,signInAnonymously} from 'firebase/auth';
import {getFirestore} from 'firebase/firestore';
const app=initializeApp({apiKey:import.meta.env.VITE_FIREBASE_API_KEY,authDomain:import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,projectId:import.meta.env.VITE_FIREBASE_PROJECT_ID,appId:import.meta.env.VITE_FIREBASE_APP_ID});
export const auth=getAuth(app);
export const db=getFirestore(app);
export async function getUser(){await auth.authStateReady();if(auth.currentUser)return auth.currentUser;const credential=await signInAnonymously(auth);return credential.user;}
