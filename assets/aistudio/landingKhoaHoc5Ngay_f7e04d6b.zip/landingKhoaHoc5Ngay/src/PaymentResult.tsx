import {useEffect,useState} from 'react';
import {onSnapshot,doc} from 'firebase/firestore';
import {CheckCircle2,Clock3,ShieldCheck} from 'lucide-react';
import {db,getUser} from './firebase';

type Order={status:'pending'|'paid';name:string;amount:number;joinUrl?:string};
export default function PaymentResult(){
 const orderId=new URLSearchParams(location.hash.split('?')[1]||'').get('order')||'';
 const [order,setOrder]=useState<Order|null>(null);
 const [error,setError]=useState('');
 useEffect(()=>{
  if(!/^FAV[A-F0-9]{24}$/.test(orderId)){setError('Mã đơn không hợp lệ.');return;}
  let unsubscribe=()=>{};let active=true;
  getUser().then(()=>{if(active)unsubscribe=onSnapshot(doc(db,'orders',orderId),snapshot=>{if(snapshot.exists())setOrder(snapshot.data() as Order);else setError('Không tìm thấy đơn hàng.');},()=>setError('Không thể xem đơn hàng bằng tài khoản này. Vui lòng mở lại trên thiết bị hoặc trình duyệt đã đặt mua.'));}).catch(()=>setError('Không thể kết nối xác thực Firebase.'));
  return()=>{active=false;unsubscribe()};
 },[orderId]);
 return <main className="result-page"><div className="result-card"><div className="result-brand">⚡ FASTAIVN / VIDEO AI 149K</div>{order?.status==='paid'?<><CheckCircle2 size={65} color="#ff4a43"/><h1>THANH TOÁN THÀNH CÔNG!</h1><p>Cảm ơn {order.name}. Mã đơn <strong>{orderId}</strong> đã được SePay xác nhận.</p><p>Khóa học: 16, 18, 21/11/2026, 20h–22h qua Zoom.</p>{order.joinUrl?<a className="primary" href={order.joinUrl} target="_blank" rel="noopener noreferrer">THAM GIA NHÓM ZALO →</a>:<p>Đang cập nhật link nhóm.</p>}<small>Hãy lưu lại trang xác nhận này trên thiết bị đã đặt mua.</small></>:<><Clock3 size={60} color="#ff4a43"/><h1>CHỜ XÁC NHẬN THANH TOÁN</h1><p>{error||'Hệ thống tự động cập nhật khi SePay gửi thông báo thanh toán hợp lệ. Không cần chuyển khoản thêm.'}</p>{order&&<p>Mã đơn: <strong>{orderId}</strong> · 149.000đ</p>}</>}<div className="result-security"><ShieldCheck size={18}/> Chỉ backend nhận IPN hợp lệ mới có quyền xác nhận thanh toán.</div><a className="result-back" href="#/">← Trở về khóa học</a></div></main>;
}
