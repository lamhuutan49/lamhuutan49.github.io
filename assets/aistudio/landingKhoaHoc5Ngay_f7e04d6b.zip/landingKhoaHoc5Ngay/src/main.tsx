import React from 'react';
import {createRoot} from 'react-dom/client';
import Home from './Home';
import PaymentResult from './PaymentResult';
import './styles.css';
const payment=location.hash.startsWith('#/payment/result');
createRoot(document.getElementById('root')!).render(<React.StrictMode>{payment?<PaymentResult/>:<Home/>}</React.StrictMode>);
